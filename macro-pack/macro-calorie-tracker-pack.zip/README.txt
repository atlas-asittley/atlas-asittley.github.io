MACRO & CALORIE TRACKER PACK
Thanks for your purchase! This pack includes 5 printable pages in BOTH US Letter and A4:
  1. Daily Food & Macro Log   2. Weekly Meal Planner   3. Grocery List
  4. Macro Cheat Sheet (set your targets)   5. Weight & Progress Tracker
HOW TO USE: Print at 100% / "Actual size". Reuse by printing more, or annotate on a tablet.
BONUS: Pair it with the free, private, no-account web tracker — atlas-asittley.github.io/calorie-tracker
No subscription. No app. Yours forever.
