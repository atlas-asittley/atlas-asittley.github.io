# Daily Puzzle Game Starter Kit 🧩

Ship your own **Wordle-style daily puzzle game** in an afternoon. This kit gives you
**two complete, polished, mobile-friendly daily games** with clean vanilla-JS source
you can rebrand and launch for free — no framework, no backend, no build step.

Perfect for indie devs, communities, brands, newsletters, or anyone who wants a
sticky "new puzzle every day" hook with a built-in **share grid** (the mechanic that
made Wordle spread).

---

## What's included
- **Spectra** — a daily *color-deduction* puzzle (guess a hidden RGB color in 6 tries).
- **Vaultle** — a daily *code-cracking* puzzle (crack a 4-digit code, Bulls & Cows).
- Both feature: deterministic **daily seed** (everyone gets the same puzzle), local
  streak/stats, a spoiler-free **shareable result grid**, an **unlimited practice
  mode**, a clean dark UI, full SEO meta + JSON-LD, and an optional tip-jar + ad hook.
- Pure HTML/CSS/JS. **No dependencies. No backend. Works offline-ish, hosts anywhere.**
- Game logic is a small, readable, unit-test-friendly module — easy to fork into your
  own puzzle.

## Quick start (2 minutes)
1. Open `games/spectra/index.html` (or `vaultle`) in a browser — it just runs.
2. To publish for free: drop the folder into a **GitHub Pages** repo (or Netlify/any
   static host). Done — it's live with a daily puzzle.

## Rebrand it as your own (5–15 minutes)
Everything is plain text, no build tools:
- **Name & copy:** edit the `<title>`, headings, and meta tags in `index.html`.
- **Colors/theme:** all colors are CSS variables at the top of `styles.css`
  (`--bg`, `--accent`, etc.) — change a few lines, reskin the whole game.
- **Tip jar:** in `game.js`, set `TIP_URL` (currently `REPLACE_WITH_YOUR_TIP_URL`) to
  your Ko-fi/Buy-Me-a-Coffee link to turn on a tasteful "tip the dev" button, or leave
  it as-is to hide it.
- **Ads:** `ads.js` is a safe no-op wrapper; wire it to your ad SDK if you monetize.
- **Difficulty:** tune the guess budget / digit count near the top of `game.js`
  (`MAX_GUESSES`, etc.).

## Make a brand-new daily puzzle
The cleanest path: copy a game folder, then edit `logic.js` — it's the pure "rules"
module (generate today's answer from the daily seed, score a guess, decide win/lose).
Keep the same function shape and the UI in `game.js` keeps working. The included
`logic.js` files are short and commented as worked examples (numeric deduction +
Bulls & Cows) you can adapt to words, emoji, math, trivia, etc.

## How the daily seed works
The puzzle is derived deterministically from the date, so **every player worldwide
gets the same puzzle each day** with no server — that shared experience is what makes
the share-grid spread. Streaks and stats live in the player's own `localStorage`.

## License
Commercial use allowed: build and launch your own games with this kit, including paid
or ad-supported ones. You may **not** resell or redistribute the kit itself as a
template/asset pack. (Single-seat license; see your purchase terms.)

## Support
Questions or want a custom puzzle type built? Contact details are on the product page.

— Built from two games that shipped live with full SEO, share grids, and tested logic.
