# Marketplace listing — Daily Puzzle Game Starter Kit
Turnkey copy for whoever lists it. Recommended marketplaces: **Gumroad** (best for
code/templates, instant payout via PayPal/bank, no review) or **itch.io** (game
audience). Listing both is fine.

**Suggested price:** $9 launch (anchor at $19, "intro" discount). Even at $9, a handful
of sales = our first real revenue. Consider a $0+ "pay what you want" tier on itch to
seed downloads/reviews, with the paid kit as the upsell.

---

### Title
Daily Puzzle Game Starter Kit — Build Your Own Wordle-Style Daily Game

### Tagline (140 char)
Two complete, rebrandable daily puzzle games (vanilla JS, no backend) with share grids, streaks & daily seeds. Ship your own in an afternoon.

### Short description
A drop-in kit to launch your own "new puzzle every day" game — the Wordle hook, minus
the work. Includes two finished, mobile-friendly games (a color-deduction puzzle and a
code-cracking puzzle), clean commented source, and a guide to reskin them or build your
own puzzle. No framework, no server, hosts free on GitHub Pages.

### Long description (paste as-is)
**Want the Wordle "daily + shareable" magic for your brand, community, or portfolio?**
This kit gives you two complete daily puzzle games you can rebrand and launch today:

- 🎨 **Spectra** — guess the hidden color in 6 tries (hot/cold per RGB channel)
- 🔓 **Vaultle** — crack the daily 4-digit code (Bulls & Cows)

**What makes it worth it**
- ✅ Two *finished*, polished, mobile-first games — not a tutorial
- ✅ Deterministic **daily seed** — everyone gets the same puzzle, no backend needed
- ✅ Spoiler-free **shareable result grid** (the viral mechanic)
- ✅ Local **streaks & stats** + an **unlimited practice mode**
- ✅ Clean **vanilla HTML/CSS/JS** — no build step, no dependencies, hosts anywhere free
- ✅ SEO meta + JSON-LD already done; optional tip-jar & ad hooks included
- ✅ Short, commented **logic module** — fork it into a word/emoji/math puzzle in minutes

**Who it's for:** indie devs, newsletter & community owners, brands wanting a daily
engagement hook, anyone learning game logic, or makers who want a fast, monetizable
side project.

Reskin it in ~10 minutes (CSS variables + a few text edits) or use the included guide
to build a brand-new puzzle on the same proven engine.

Commercial-use license included. Instant download.

### Tags
wordle, daily puzzle, game template, html5 game, javascript, vanilla js, no backend,
puzzle, game kit, indie game, source code, web game, starter kit

---

## Turnkey upload steps (for Drew — ~5 min, one time)
1. Zip the kit: `cd ~/money-maker/products && zip -r daily-puzzle-kit.zip daily-puzzle-kit` (I can also do this and hand you the file).
2. **Gumroad:** sign up (gumroad.com) → New Product → Digital Product → upload the zip,
   paste the Title + Long description + Tags above, set price $9 → connect PayPal/bank
   payout → Publish. (No review; live immediately.)
3. Send me the product URL → I add a "Get the kit" link from our live games + tools (free
   cross-promo from assets that will get some traffic), and I draft a Show HN / r/gamedev
   post you *can* use if/when you want a launch bump.

That's the whole human step. Everything above this line I've already done.
