// ads.js — thin wrapper over the Playgama Bridge ad SDK.
//
// SAFE BY DESIGN: if the Bridge script isn't loaded (e.g. on our own
// github.io site), every call is a silent no-op, so the game is unaffected.
// It only does anything once we publish through Playgama (where the Bridge
// <script> tag + playgama-bridge-config.json are added — see ops/playgama/).
(function () {
  var initPromise = null;
  // Initialize once; reuse the promise so every ad call waits for readiness
  // instead of being dropped if the SDK hasn't finished initializing yet.
  function ensureReady() {
    if (!window.bridge || !bridge.initialize) return Promise.reject();
    if (!initPromise) {
      initPromise = bridge.initialize().then(function () {
        try { bridge.platform.sendMessage('game_ready'); } catch (e) {}
      });
    }
    return initPromise;
  }
  try { ensureReady().catch(function () {}); } catch (e) {}

  window.AAds = {
    // Show an interstitial at a natural pause (no cooldown — Playgama applies its
    // own frequency capping). Waits for the SDK to be ready, then shows.
    interstitial: function (placement) {
      try {
        if (!window.bridge) return;
        ensureReady().then(function () {
          try { bridge.advertisement.showInterstitial(placement || 'break'); } catch (e) {}
        }).catch(function () {});
      } catch (e) {}
    },
    // Optional rewarded ad. Resolves true only if the reward was actually earned.
    rewarded: function (placement) {
      return new Promise(function (resolve) {
        if (!window.bridge) return resolve(false);
        ensureReady().then(function () {
          try {
            var settled = false;
            bridge.advertisement.on(bridge.EVENT_NAME.REWARDED_STATE_CHANGED, function (state) {
              if (state === 'rewarded') { settled = true; resolve(true); }
              else if ((state === 'closed' || state === 'failed') && !settled) { settled = true; resolve(false); }
            });
            bridge.advertisement.showRewarded(placement || 'reward');
          } catch (e) { resolve(false); }
        }).catch(function () { resolve(false); });
      });
    },
  };
})();
