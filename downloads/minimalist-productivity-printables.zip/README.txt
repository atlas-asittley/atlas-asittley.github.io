MINIMALIST PRODUCTIVITY PRINTABLE PACK
Thanks for your purchase!

Included (US Letter + A4, print-ready PDF):
  - Daily Planner
  - Weekly Planner
  - Habit Tracker (monthly)
  - Monthly Goals & Reflection

How to use: print at home or at a print shop (works great on standard paper),
or write on it digitally with any PDF/notes app (GoodNotes, Notability, etc.).
Print as many copies as you like for your own personal use.

License: personal use. Please don't resell or redistribute the files.
Enjoy — and here's to a more organized week.
